#include <stdint.h>
#include <string.h>
#include "CPU.h"

// From https://github.com/superzazu/8080
const uint8_t InstructionCycles[] = {
//  0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F
	4,  10, 7,  5,  5,  5,  7,  4,  4,  10, 7,  5,  5,  5,  7,  4,  // 0
	4,  10, 7,  5,  5,  5,  7,  4,  4,  10, 7,  5,  5,  5,  7,  4,  // 1
	4,  10, 16, 5,  5,  5,  7,  4,  4,  10, 16, 5,  5,  5,  7,  4,  // 2
	4,  10, 13, 5,  10, 10, 10, 4,  4,  10, 13, 5,  5,  5,  7,  4,  // 3
	5,  5,  5,  5,  5,  5,  7,  5,  5,  5,  5,  5,  5,  5,  7,  5,  // 4
	5,  5,  5,  5,  5,  5,  7,  5,  5,  5,  5,  5,  5,  5,  7,  5,  // 5
	5,  5,  5,  5,  5,  5,  7,  5,  5,  5,  5,  5,  5,  5,  7,  5,  // 6
	7,  7,  7,  7,  7,  7,  7,  7,  5,  5,  5,  5,  5,  5,  7,  5,  // 7
	4,  4,  4,  4,  4,  4,  7,  4,  4,  4,  4,  4,  4,  4,  7,  4,  // 8
	4,  4,  4,  4,  4,  4,  7,  4,  4,  4,  4,  4,  4,  4,  7,  4,  // 9
	4,  4,  4,  4,  4,  4,  7,  4,  4,  4,  4,  4,  4,  4,  7,  4,  // A
	4,  4,  4,  4,  4,  4,  7,  4,  4,  4,  4,  4,  4,  4,  7,  4,  // B
	5,  10, 10, 10, 11, 11, 7,  11, 5,  10, 10, 10, 11, 11, 7,  11, // C
	5,  10, 10, 10, 11, 11, 7,  11, 5,  10, 10, 10, 11, 11, 7,  11, // D
	5,  10, 10, 18, 11, 11, 7,  11, 5,  5,  10, 5,  11, 11, 7,  11, // E
	5,  10, 10, 4,  11, 11, 7,  11, 5,  5,  10, 4,  11, 11, 7,  11  // F
};

CPU::CPU(MMU* _mmu, uint8_t _ConsoleMode)
{
    InterruptsEnabled = 0;
    Halt = 0;
    ClockCount = 0;
    ConsoleMode = _ConsoleMode;

    mmu = _mmu;
    WorkValue = 0;

    memset(InPort, 0, sizeof(InPort));
    memset(OutPort, 0, sizeof(OutPort));

    InPort[0] |= 1 << 1;
    InPort[0] |= 1 << 2;
    InPort[0] |= 1 << 3;
    InPort[1] |= 1 << 3;

    reg_SHIFT = 0;
    ShiftOffset = 0;

    true_reg_A = 0;
    reg_BC = 0;
    reg_DE = 0;
    reg_HL = 0;

    SP = 0;
    PC = 0;

    Flag_S = 0;
    Flag_Z = 0;
    Flag_AC = 0;
    Flag_P = 0;
    Flag_C = 0;

    if (ConsoleMode)
    {
        SetByteAt(0x5, 0b11001001);
        SetByteAt(0x6, 0xFF);
        SetByteAt(0x7, 0xFF);

        PC = 0x100;
    }

    for (int i = 0; i <= 0xFF; i++)
    {
        FlagZSP[i] = (i == 0) << 0;
        FlagZSP[i] |= (i >> 7) << 1;

        uint8_t Bit1Count = 0;
        for (int k = 0; k < 8; k++)
        {
            if (((i >> k) & 1) == 1)
                Bit1Count++;
        }
        FlagZSP[i] |= ((Bit1Count & 1) == 0) << 2;
    }
}

inline void CPU::Debug () {
	printf ("\nRegisters: --------------------------------\n");
	printf ("A: 0x%02x\n", *reg_A);
	printf ("B: 0x%02x\n", *reg_B);
	printf ("C: 0x%02x\n", *reg_C);
	printf ("D: 0x%02x\n", *reg_D);
	printf ("E: 0x%02x\n", *reg_E);
	printf ("H: 0x%02x\n", *reg_H);
	printf ("L: 0x%02x\n", *reg_L);
	if (ConsoleMode)
		printf ("M: 0x%02x\n", GetByteAt(reg_HL));
	else
		printf ("M: ??\n");
	
	printf ("SP: 0x%04x\n", SP);
	printf ("PC: 0x%04x\n", PC - 1);

	printf ("\nRegister Pairs: --------------------------------\n");
	printf ("BC: 0x%04x\n", reg_BC);
	printf ("DE: 0x%04x\n", reg_DE);
	printf ("HL: 0x%04x\n", reg_HL);

	printf ("\nFlags: --------------------------------\n");
	printf ("Z : 0x%02x\n", Flag_Z);
	printf ("S : 0x%02x\n", Flag_S);
	printf ("P : 0x%02x\n", Flag_P);
	printf ("C : 0x%02x\n", Flag_C);
	printf ("AC: 0x%02x\n", Flag_AC);

	printf ("\n");
}

inline uint8_t CPU::GetByteAt(uint16_t Address)
{
    return *mmu->MemoryMap[Address];
}

inline void CPU::SetByteAt(uint16_t Address, uint8_t value)
{
    if (ConsoleMode || (!ConsoleMode && Address >= 0x2000 && Address <= 0x4000))
    {
        *mmu->MemoryMap[Address] = value;
    }
}

inline uint16_t CPU::GetWordAt(uint16_t Address)
{
    return GetByteAt(Address) | (GetByteAt(Address + 1) << 8);
}

inline void CPU::SetWordAt(uint16_t Address, uint16_t value)
{
    SetByteAt(Address, value & 0xFF);
    SetByteAt(Address, value >> 8);
}

inline void CPU::StackPush(uint16_t value)
{
    SP -= 2;
    SetWordAt(SP, value);
}

inline uint16_t CPU::StackPop()
{
    uint16_t value = GetWordAt(SP);
    SP += 2;
    return value;
}

inline void CPU::PushPSW()
{
    uint16_t PSW = ((uint16_t) *reg_A) << 8;
    PSW |= Flag_C;
    PSW |= 1 << 1;
    PSW |= Flag_P << 2;
    PSW |= 0 << 3;
	PSW |= Flag_AC << 4;
	PSW |= 0 << 5;
	PSW |= Flag_Z << 6;
	PSW |= Flag_S << 7;

    StackPush(PSW);
}

inline void CPU::PopPSW () {
	uint16_t PSW = StackPop();
	*reg_A = PSW >> 8;
	Flag_C = PSW & 1;
	Flag_P = (PSW >> 2) & 1;
	Flag_AC = (PSW >> 4) & 1;
	Flag_Z = (PSW >> 6) & 1;
	Flag_S = (PSW >> 7) & 1;
}

inline uint8_t GetCarry(uint8_t OpA, uint8_t OpB, uint8_t Carry, uint8_t Bit)
{
    int16_t Result = OpA + OpB + Carry;
    int16_t NewCarry = Result ^ OpA ^ OpB;
    return (NewCarry & (1 << Bit)) != 0;
}

inline void CPU::SetZSP(uint8_t value)
{
    Flag_Z = (FlagZSP[value] >> 0) & 1;
    Flag_S = (FlagZSP[value] >> 1) & 1;
    Flag_P = (FlagZSP[value] >> 2) & 1;
}

inline void CPU::SetFlagsAdd (uint8_t OpA, uint8_t OpB, uint8_t Carry, uint8_t CarryMode) {
	const uint8_t Result = OpA + OpB + Carry;
	
	switch (CarryMode) {
	case 0: Flag_C = 0; Flag_AC = 0; break; // Clear
	case 1: Flag_C = GetCarry (OpA, OpB, Carry, 8); Flag_AC = GetCarry (OpA, OpB, Carry, 4); break; // Normal
	case 2: Flag_C = GetCarry (OpA, OpB, Carry, 8); break; // Only C
	case 3: Flag_AC = GetCarry (OpA, OpB, Carry, 4); break; // Only AC
	}
	
	SetZSP (Result);
}

inline void CPU::SetFlagsSub (uint8_t OpA, uint8_t OpB, uint8_t Carry, uint8_t CarryMode) {
	SetFlagsAdd (OpA, ~OpB, 1 - Carry, CarryMode); // The Carry will make up for ~OpB
	
	switch (CarryMode) {
		case 1: Flag_C = 1 - Flag_C; break; // Normal
		default: break;
	}
}

void CPU::Interrupt(uint8_t ID)
{
    
}