#include <stdint.h>
#pragma once

class MMU
{
public:
    MMU(uint8_t ConsoleMode);

    uint16_t ROMAddress = 0x0000;
	uint16_t RAMAddress = 0x2000;
	uint16_t VRAMAddress = 0x2400;
	uint16_t RAMMirrorAddress = 0x4000;

    uint8_t* VRAM = Memory + VRAMAddress;
    
    uint8_t* MemoryMap[0x10000];
    void LoadInMemory(uint8_t* Buffer, uint16_t Address, int BufferSize);
private:
    uint8_t JunkValue;
    uint8_t Memory[0x10000];
};