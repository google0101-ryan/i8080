#pragma once

#include <stdint.h>
#include <stdio.h>
#include "MMU.h"

class CPU
{
public:
    CPU(MMU* _mmu, uint8_t _ConsoleMode);
    void Clock();
    void Interrupt(uint8_t ID);

    uint8_t InPort[4];
    uint8_t OutPort[7];

    uint8_t InterruptsEnabled;
    uint8_t Halt;
    uint64_t ClockCount;
    uint64_t InstructionCount;
    uint8_t ConsoleMode;
private:
    MMU* mmu;

    uint16_t reg_SHIFT;
    uint8_t ShiftOffset;

    uint16_t WorkValue;

    uint8_t* reg_M;
    uint8_t true_reg_A;
    uint8_t* reg_A = &true_reg_A;

    uint16_t reg_BC;
	uint8_t* reg_B = ((uint8_t*) &reg_BC) + 1;
	uint8_t* reg_C = ((uint8_t*) &reg_BC);
	uint16_t reg_DE;
	uint8_t* reg_D = ((uint8_t*) &reg_DE) + 1;
	uint8_t* reg_E = ((uint8_t*) &reg_DE);
	uint16_t reg_HL;
	uint8_t* reg_H = ((uint8_t*) &reg_HL) + 1;
	uint8_t* reg_L = ((uint8_t*) &reg_HL);

	uint16_t PC, SP;

    uint8_t FlagZSP[0x100];
    uint8_t Flag_Z, Flag_S, Flag_P, Flag_C, Flag_AC;

    void Syscall(uint8_t ID);
    void Execute(uint8_t Instruction);

    uint8_t GetByteAt(uint16_t Address);
    void SetByteAt(uint16_t Address, uint8_t value);
    uint16_t GetWordAt(uint16_t Address);
    void SetWordAt(uint16_t Address, uint16_t value);
    void PushPSW();
    void PopPSW();

    uint16_t StackPop();
    void StackPush(uint16_t value);

    void SetFlagsAdd (uint8_t OpA, uint8_t OpB, uint8_t Carry, uint8_t CarryMode);
	void SetFlagsSub (uint8_t OpA, uint8_t OpB, uint8_t Carry, uint8_t CarryMode);
	void SetZSP (uint8_t Value);

    void Debug();
};